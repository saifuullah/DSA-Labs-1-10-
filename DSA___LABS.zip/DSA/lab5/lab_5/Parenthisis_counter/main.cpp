#include <fstream>
#include <iostream>
using namespace std;
int open=1,close=0;
class Parenthisis
{
public:
bool openFile(ifstream &obj,char *nameOfFile)    //bool function will test if file can be open or not
{
    bool status;
    obj.open(nameOfFile, ios::in);
    if(obj.fail())
        status = false;
    else
        status = true;
    return status;
} //END

void counter()      ///counter function
{
      ifstream file_obj;
  if(!openFile(file_obj,"main.cpp"))
    cout<<"sorry file cannot be opened "<<endl;
  else
  {
  readfile(file_obj);
  }
}//END


void readfile(ifstream &file)
{
char ch;
while(file.eof()==0)
{
    file >> ch;
    if(ch=='{' || ch == '(')
        open++;
    else
        if(ch=='}' || ch==')')
        close++;
}
if(close==open)
{
         cout<<"Parenthisis are Equal "<<endl;
}
      else
    cout<<"Parenthisis Opening and Closing is Not Equal "<<endl;


}//END

};// CLASS END HERE ))((



int main()
{
    Parenthisis myP;
    myP.counter();

}
