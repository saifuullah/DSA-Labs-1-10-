#include <iostream>
#include <string.h>
#include <fstream>
#include <stdlib.h>
using namespace std;
class Node
{
private:
    Node *next;
    Node *prevv;
    int data;
public:
    void setNextNode(Node *n)
    {   next=n;
    }
    int getData()
    {
        return data;
    }
void setPrev(Node *n)
{
    prevv=n;
}

    Node *getNextNode()
    {   return next;
    }
Node *getPrev()
{
    return prevv;
}
    Node(int d)
    {   next=NULL;
        data=d;
        prevv=NULL;
    }

    Node()
    {
         next=NULL;
         prevv=NULL;
    }

};/// CLASS END PARENTHESIS

/**       **********    First Class End      *************
*         *******       Second Class            **********
*         ****         D-Linked_List Class         *******
*
**/

class Linked_List
{
private:
    Node *first;
    Node *NONE;  /// to set pointer to null
    Node *last;
public:

Linked_List()
{
    first=NULL;
    NONE =NULL;
    last=NULL;
}

  void enQueue(int dat)      ///THIS FUNCTION WILL ADD AT END OF THE LIST
  {
      Node *temp=new Node(dat);
      Node *temp2=first;
      if(first==NULL)
        {
            first=temp;
            last=first;
        }
        else
        {
          last->setNextNode(temp);
          last->getNextNode()->setPrev(last);
          last=last->getNextNode();
        }
  }//END


    void display_all()             ///This Will display list
    {   Node *temp=first;
    if(first==NULL)
        cout<<"Sorry, List is Empty :)  "<<endl;
    else{
        while(temp !=NULL)
        {   cout<<temp->getData()<<endl;
            temp=temp->getNextNode();
        }
    }
    }//End

    void deQueue()          ///THIS WILL REMOVE THE FIRST VALUE
    {
        if(first==NULL)
            cout<<"Sorry, List is Empty Nothing to Delete :) "<<endl;

    else
        if(first->getNextNode()==NULL)
        first=NULL;
    else
        first=first->getNextNode();
        //first->setPrev(NONE);
    }//END

};//class End




int main()
{
    Linked_List mylist;
    int choice;
    char ch;
    bool exit=false;

    do{

    system("CLS");
    cout<<endl<<"1 For Enqueue : "<<endl;
    cout<<"2 For Dequeue :"<<endl;
    cout<<"3 For Display :"<<endl<<endl;
cout<<"Enter Your Choice : ";
cin>>choice;

switch(choice)
{
case 1:
    cout<<"Enter Value To Enqueue >> ";
    cin>>choice;
    mylist.enQueue(choice);
    break;
case 2:
    mylist.deQueue();
    break;
case 3:
    mylist.display_all();
    break;
default:
    cout<<"Invalid operation !!!!!"<<endl;

}//SWITCH

    cout<<endl<<"Do you want to Continue?  (y/n)   : " ;
    cin>>ch;
    if(ch=='n' || ch=='N')
        exit=true;
    }while(!exit);

    return 0;
}
