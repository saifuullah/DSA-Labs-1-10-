#include <iostream>

using namespace std;


class Hashing
{
private:
    int hashTable[100];
    int number;
public:
    Hashing ()
    {
        for(int x=0; x<100; x++)
        {
            hashTable[x]= 0;
        }
        number=0;
    }






    int hashFunction(int num)
    {
        return num % 100;
    }


    void addData(int d)
    {
        int index=hashFunction(d);
        //Now Hash function will return index


        if(hashTable[index]==0 || hashTable[index]==-1)
            hashTable[index]=d;
        else
        {
                int ind = prob(d, 0);
                    hashTable[ind]=d;
        }
        number++;
    }

int isFull()
{
    if(number==100)
        return 0;
    else
        return number;
}

int isEmpty()
{
    if(number == 0)
        return 0;
    else
        return 1;
}


    int prob(int num,int i)
    {
     int ind;

     ind = hashFunction( hashFunction(num) + i );
     if(hashTable[ind]==0 || hashTable[ind]==-1)
        return ind;
     else prob(num, ++i);
    }



    void display()
    {
        for(int i=0; i<100; i++)
           {
               if(hashTable[i]==0 || hashTable[i]==-1)
                int x=0;
               else
                cout<<hashTable[i]<<endl;

            }
    }







    void deleteData(int d)
    {
        number--;
        int dat=hashTable[d];
       hashTable[d]=-1;
       cout << "Data "<<dat<<" is Deleted from Index "<<d<<endl;

    }//DeleteData Function END




    int searchData(int d)
    {
        int ind = hashFunction(d);
        if(hashTable[ind] == d)
            return ind;
        else
        {
            int x = probSearch(d, 0);
            if(x==0)
                return 0;
            else
                return x;
        }
    }




    int probSearch(int num,int i)
    {
     int ind;
     ind = hashFunction( hashFunction(num) + i );
     if(hashTable[ind]== 0)
        return 0;
     if(hashTable[ind]==num)
        return ind;
     else probSearch(num, ++i);
    }




};



//Class Hashing End
int main()
{
int choice,d;
char ch;
Hashing myO;

do{

    cout<<"1. For Add "<<endl;
    cout<<"2. Display "<<endl;
    cout<<"3. For IsEmpty "<<endl;
    cout<<"4. For IsFull "<<endl;
    cout<<"5. For Delete Data "<<endl;
    cout<<"6. For Search Data "<<endl;

    cin >> choice;

    switch(choice)
    {


    case 1:

        cout<<"Enter Data : " ;
        cin >> d;
        myO.addData(d);
        break;



    case 2:


        myO.display();
        break;

    case 3:
        d = myO.isEmpty();
        if(d==0)
            cout<<"Array is Empty "<<endl;
        else
            cout<<"Array is Not Empty "<<endl;

        break;


    case 4:

        d = myO.isFull();

         if(d==0)
            cout<<"Array is Full "<<endl;
        else
            cout<<"Array is Not Full, it contain "<<d<<" Elements " <<endl;

            break;
    case 5:

        cout << "Enter Data you want to delete : "<<endl;
        cin >> d;
        choice = myO.searchData(d);
        if(choice == 0)
            cout << "Data is Not Found "<<endl;
        else
           myO.deleteData(choice);
        break;


    case 6:

         cout << "Enter Data you want to Search : "<<endl;
        cin >> d;
        choice = myO.searchData(d);
        if(choice == 0)
            cout << "Data is Not Found "<<endl;
        else
            cout<<"Data is Placed on Index : "<<choice<<endl;
        break;

    }

    cout<<endl<<"Do you want to continue  (y/n) :  " ;
    cin >> ch;

}while(ch!='n');


    return 0;
}
